grant all privileges on quickfix.* 
to 'fiximulator'@'localhost' 
identified by 'fiximulator';